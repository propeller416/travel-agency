package org.example.travel_agency;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class TravelAgencyApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {

        // Диагностика - выведет все доступные ресурсы
        System.out.println("Classpath: " + System.getProperty("java.class.path"));
        System.out.println("Проверка путей:");
        System.out.println("  main.fxml: " + getClass().getResource("main.fxml"));
        System.out.println("  /main.fxml: " + getClass().getResource("/main.fxml"));
        System.out.println("  /fxml/main.fxml: " + getClass().getResource("/fxml/main.fxml"));

        // Используем getResource относительно класса
        FXMLLoader loader = new FXMLLoader(TravelAgencyApp.class.getResource("main.fxml"));

        if (loader.getLocation() == null) {
            System.err.println("❌ Не найден main.fxml! Проверьте путь.");
            System.err.println("Пытался найти: " + TravelAgencyApp.class.getResource("main.fxml"));
            System.exit(1);
        }

        Parent root = loader.load();

        MainController mainController = loader.getController();

        Scene scene = new Scene(root);

        primaryStage.setTitle("Туристическое агентство");
        primaryStage.setScene(scene);
        primaryStage.setMinWidth(900);
        primaryStage.setMinHeight(600);
        primaryStage.show();
    }

    @Override
    public void stop() {
        DatabaseConnection.closeConnection();
    }

    public static void main(String[] args) {
        launch(args);
    }
}