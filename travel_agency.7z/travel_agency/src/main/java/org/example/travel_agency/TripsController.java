package org.example.travel_agency;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class TripsController implements Initializable {

    @FXML
    private TableView<Trip> tripsTable;
    @FXML
    private TableColumn<Trip, String> destinationCol;
    @FXML
    private TableColumn<Trip, String> descriptionCol;
    @FXML
    private TableColumn<Trip, Double> priceCol;
    @FXML
    private TableColumn<Trip, Integer> durationCol;
    @FXML
    private TableColumn<Trip, LocalDate> startDateCol;
    @FXML
    private TableColumn<Trip, Integer> availableSlotsCol;

    private TripDAO tripDAO;
    private ObservableList<Trip> tripsData;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        tripDAO = new TripDAO();
        tripsData = FXCollections.observableArrayList();

        setupTableColumns();

        // Проверяем подключение перед загрузкой данных
        if (DatabaseConnection.getConnection() != null) {
            loadTripsData();
        } else {
            System.err.println("⚠️ Нет подключения к БД, данные не загружены");
            AlertUtil.showError("Ошибка БД", "Не удалось подключиться к базе данных");
        }

        // Двойной клик для бронирования
        tripsTable.setRowFactory(tv -> {
            TableRow<Trip> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && !row.isEmpty()) {
                    openBookingDialog(row.getItem());
                }
            });
            return row;
        });
    }

    private void setupTableColumns() {
        destinationCol.setCellValueFactory(new PropertyValueFactory<>("destination"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        durationCol.setCellValueFactory(new PropertyValueFactory<>("durationDays"));
        startDateCol.setCellValueFactory(new PropertyValueFactory<>("startDate"));
        availableSlotsCol.setCellValueFactory(new PropertyValueFactory<>("availableSlots"));

        // Форматирование цены
        priceCol.setCellFactory(tc -> new TableCell<Trip, Double>() {
            @Override
            protected void updateItem(Double price, boolean empty) {
                super.updateItem(price, empty);
                if (empty || price == null) {
                    setText(null);
                } else {
                    setText(String.format("%,.2f ₽", price));
                }
            }
        });
    }

    private void loadTripsData() {
        tripsData.clear();
        tripsData.addAll(tripDAO.getAllTrips());
        tripsTable.setItems(tripsData);
    }

    @FXML
    private void handleRefresh() {
        if (DatabaseConnection.getConnection() != null) {
            loadTripsData();
            AlertUtil.showInfo("Обновление", "Список поездок обновлен");
        } else {
            AlertUtil.showError("Ошибка", "Нет подключения к базе данных");
        }
    }

    @FXML
    private void handleBookTrip() {
        Trip selectedTrip = tripsTable.getSelectionModel().getSelectedItem();
        if (selectedTrip != null) {
            openBookingDialog(selectedTrip);
        } else {
            AlertUtil.showWarning("Внимание", "Пожалуйста, выберите поездку для бронирования");
        }
    }

    private void openBookingDialog(Trip trip) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("booking_dialog.fxml"));
            Parent root = loader.load();

            BookingDialogController controller = loader.getController();
            controller.setTrip(trip);
            controller.setTripsController(this);

            Stage dialogStage = new Stage();
            dialogStage.setTitle("Бронирование: " + trip.getDestination());
            dialogStage.initModality(Modality.APPLICATION_MODAL);
            dialogStage.setScene(new Scene(root));
            dialogStage.setResizable(false);
            dialogStage.show();

        } catch (IOException e) {
            e.printStackTrace();
            AlertUtil.showError("Ошибка", "Не удалось открыть окно бронирования");
        }
    }

    public void refreshTrips() {
        loadTripsData();
    }
}