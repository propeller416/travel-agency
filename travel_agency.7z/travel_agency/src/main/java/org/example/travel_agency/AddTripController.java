package org.example.travel_agency;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class AddTripController implements Initializable {

    @FXML
    private TextField destinationField;
    @FXML
    private TextArea descriptionArea;
    @FXML
    private TextField priceField;
    @FXML
    private TextField durationField;
    @FXML
    private DatePicker startDatePicker;
    @FXML
    private TextField slotsField;

    private TripDAO tripDAO;
    private MainController mainController;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        tripDAO = new TripDAO();
        startDatePicker.setValue(LocalDate.now().plusDays(30));

        setupValidation();
    }

    private void setupValidation() {
        // Только цифры и точка для цены
        priceField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*\\.?\\d*")) {
                priceField.setText(oldValue);
            }
        });

        // Только цифры для длительности
        durationField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                durationField.setText(oldValue);
            }
        });

        // Только цифры для количества мест
        slotsField.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                slotsField.setText(oldValue);
            }
        });
    }

    public void setMainController(MainController mainController) {
        this.mainController = mainController;
    }

    @FXML
    private void handleAddTrip() {
        if (!validateInput()) {
            return;
        }

        try {
            String destination = destinationField.getText().trim();
            String description = descriptionArea.getText().trim();
            double price = Double.parseDouble(priceField.getText().trim());
            int duration = Integer.parseInt(durationField.getText().trim());
            LocalDate startDate = startDatePicker.getValue();
            int slots = Integer.parseInt(slotsField.getText().trim());

            Trip newTrip = new Trip(destination, description, price, duration, startDate, slots);
            boolean success = tripDAO.addTrip(newTrip);

            if (success) {
                AlertUtil.showInfo("Успех", "Поездка успешно добавлена!");
                clearForm();

                if (mainController != null) {
                    mainController.switchToTab(0);
                }
            } else {
                AlertUtil.showError("Ошибка", "Не удалось добавить поездку");
            }
        } catch (NumberFormatException e) {
            AlertUtil.showError("Ошибка", "Пожалуйста, введите корректные числовые значения");
        }
    }

    private boolean validateInput() {
        if (destinationField.getText().trim().isEmpty()) {
            AlertUtil.showWarning("Внимание", "Пожалуйста, укажите направление");
            return false;
        }

        if (descriptionArea.getText().trim().isEmpty()) {
            AlertUtil.showWarning("Внимание", "Пожалуйста, укажите описание");
            return false;
        }

        if (priceField.getText().trim().isEmpty()) {
            AlertUtil.showWarning("Внимание", "Пожалуйста, укажите стоимость");
            return false;
        }

        if (durationField.getText().trim().isEmpty()) {
            AlertUtil.showWarning("Внимание", "Пожалуйста, укажите длительность");
            return false;
        }

        if (startDatePicker.getValue() == null) {
            AlertUtil.showWarning("Внимание", "Пожалуйста, выберите дату начала");
            return false;
        }

        if (slotsField.getText().trim().isEmpty()) {
            AlertUtil.showWarning("Внимание", "Пожалуйста, укажите количество мест");
            return false;
        }

        return true;
    }

    private void clearForm() {
        destinationField.clear();
        descriptionArea.clear();
        priceField.clear();
        durationField.clear();
        startDatePicker.setValue(LocalDate.now().plusDays(30));
        slotsField.clear();
    }
}