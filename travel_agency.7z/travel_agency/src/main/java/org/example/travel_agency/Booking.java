package org.example.travel_agency;

import java.time.LocalDateTime;

public class Booking {
    private int id;
    private int tripId;
    private String customerName;
    private String phoneNumber;
    private LocalDateTime bookingDate;
    private String status;

    public Booking(int id, int tripId, String customerName, String phoneNumber,
                   LocalDateTime bookingDate, String status) {
        this.id = id;
        this.tripId = tripId;
        this.customerName = customerName;
        this.phoneNumber = phoneNumber;
        this.bookingDate = bookingDate;
        this.status = status;
    }

    public Booking(int tripId, String customerName, String phoneNumber) {
        this(0, tripId, customerName, phoneNumber, LocalDateTime.now(), "confirmed");
    }

    // Геттеры и сеттеры
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getTripId() { return tripId; }
    public void setTripId(int tripId) { this.tripId = tripId; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public LocalDateTime getBookingDate() { return bookingDate; }
    public void setBookingDate(LocalDateTime bookingDate) { this.bookingDate = bookingDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}