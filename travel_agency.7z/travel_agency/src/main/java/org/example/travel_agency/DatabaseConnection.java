package org.example.travel_agency;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/travel_agency?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASSWORD = "propeller416";

    public static Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("✅ Подключение к базе данных установлено!");
        } catch (ClassNotFoundException e) {
            System.err.println("❌ Драйвер MySQL не найден!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("❌ Ошибка подключения к базе данных: " + e.getMessage());
        }
        return connection;
    }

    // Метод closeConnection больше не нужен, но оставим для совместимости
    public static void closeConnection() {
        // Соединения теперь закрываются автоматически через try-with-resources
    }
}