package org.example.travel_agency;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.net.URL;
import java.util.ResourceBundle;

public class BookingDialogController implements Initializable {

    @FXML
    private Label destinationLabel;
    @FXML
    private Label priceLabel;
    @FXML
    private Label durationLabel;
    @FXML
    private Label startDateLabel;
    @FXML
    private Label availableSlotsLabel;
    @FXML
    private TextField nameField;
    @FXML
    private TextField phoneField;

    private Trip trip;
    private TripsController tripsController;
    private TripDAO tripDAO;
    private BookingDAO bookingDAO;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        tripDAO = new TripDAO();
        bookingDAO = new BookingDAO();
    }

    public void setTrip(Trip trip) {
        this.trip = trip;
        updateTripInfo();
    }

    public void setTripsController(TripsController tripsController) {
        this.tripsController = tripsController;
    }

    private void updateTripInfo() {
        if (trip != null) {
            destinationLabel.setText(trip.getDestination());
            priceLabel.setText(String.format("%,.2f ₽", trip.getPrice()));
            durationLabel.setText(trip.getDurationDays() + " дней");
            startDateLabel.setText(trip.getStartDate().toString());
            availableSlotsLabel.setText(String.valueOf(trip.getAvailableSlots()));
        }
    }

    @FXML
    private void handleBook() {
        String customerName = nameField.getText().trim();
        String phoneNumber = phoneField.getText().trim();

        if (customerName.isEmpty() || phoneNumber.isEmpty()) {
            AlertUtil.showWarning("Внимание", "Пожалуйста, заполните все поля");
            return;
        }

        if (trip.getAvailableSlots() <= 0) {
            AlertUtil.showError("Ошибка", "К сожалению, на эту поездку нет свободных мест");
            closeDialog();
            return;
        }

        Booking booking = new Booking(trip.getId(), customerName, phoneNumber);
        boolean bookingSuccess = bookingDAO.addBooking(booking);

        if (bookingSuccess) {
            int newAvailableSlots = trip.getAvailableSlots() - 1;
            boolean updateSuccess = tripDAO.updateAvailableSlots(trip.getId(), newAvailableSlots);

            if (updateSuccess) {
                AlertUtil.showInfo("Успех", "Бронирование успешно оформлено!");

                if (tripsController != null) {
                    tripsController.refreshTrips();
                }

                closeDialog();
            } else {
                AlertUtil.showError("Ошибка", "Не удалось обновить количество мест");
            }
        } else {
            AlertUtil.showError("Ошибка", "Не удалось оформить бронирование");
        }
    }

    @FXML
    private void handleCancel() {
        closeDialog();
    }

    private void closeDialog() {
        Stage stage = (Stage) nameField.getScene().getWindow();
        stage.close();
    }
}