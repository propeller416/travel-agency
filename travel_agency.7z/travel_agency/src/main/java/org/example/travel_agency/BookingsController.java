package org.example.travel_agency;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

public class BookingsController implements Initializable {

    @FXML
    private TableView<Booking> bookingsTable;
    @FXML
    private TableColumn<Booking, Integer> idCol;
    @FXML
    private TableColumn<Booking, Integer> tripIdCol;
    @FXML
    private TableColumn<Booking, String> customerNameCol;
    @FXML
    private TableColumn<Booking, String> phoneNumberCol;
    @FXML
    private TableColumn<Booking, LocalDateTime> bookingDateCol;
    @FXML
    private TableColumn<Booking, String> statusCol;

    private BookingDAO bookingDAO;
    private ObservableList<Booking> bookingsData;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        bookingDAO = new BookingDAO();
        bookingsData = FXCollections.observableArrayList();

        setupTableColumns();
        loadBookingsData();
    }

    private void setupTableColumns() {
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        tripIdCol.setCellValueFactory(new PropertyValueFactory<>("tripId"));
        customerNameCol.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        phoneNumberCol.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        bookingDateCol.setCellValueFactory(new PropertyValueFactory<>("bookingDate"));
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));

        // Форматирование даты
        bookingDateCol.setCellFactory(tc -> new TableCell<Booking, LocalDateTime>() {
            private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");

            @Override
            protected void updateItem(LocalDateTime date, boolean empty) {
                super.updateItem(date, empty);
                if (empty || date == null) {
                    setText(null);
                } else {
                    setText(date.format(formatter));
                }
            }
        });
    }

    private void loadBookingsData() {
        bookingsData.clear();
        bookingsData.addAll(bookingDAO.getAllBookings());
        bookingsTable.setItems(bookingsData);
    }

    @FXML
    private void handleRefresh() {
        loadBookingsData();
        AlertUtil.showInfo("Обновление", "Список бронирований обновлен");
    }
}