package org.example.travel_agency;

import java.time.LocalDate;

public class Trip {
    private int id;
    private String destination;
    private String description;
    private double price;
    private int durationDays;
    private LocalDate startDate;
    private int availableSlots;

    public Trip(int id, String destination, String description, double price,
                int durationDays, LocalDate startDate, int availableSlots) {
        this.id = id;
        this.destination = destination;
        this.description = description;
        this.price = price;
        this.durationDays = durationDays;
        this.startDate = startDate;
        this.availableSlots = availableSlots;
    }

    public Trip(String destination, String description, double price,
                int durationDays, LocalDate startDate, int availableSlots) {
        this(0, destination, description, price, durationDays, startDate, availableSlots);
    }

    // Геттеры и сеттеры
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public int getDurationDays() { return durationDays; }
    public void setDurationDays(int durationDays) { this.durationDays = durationDays; }

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }

    public int getAvailableSlots() { return availableSlots; }
    public void setAvailableSlots(int availableSlots) { this.availableSlots = availableSlots; }
}