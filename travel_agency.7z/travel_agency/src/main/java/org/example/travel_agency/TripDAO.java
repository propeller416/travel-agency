package org.example.travel_agency;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TripDAO {

    public List<Trip> getAllTrips() {
        List<Trip> trips = new ArrayList<>();
        String query = "SELECT * FROM trips ORDER BY start_date";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Trip trip = new Trip(
                        rs.getInt("id"),
                        rs.getString("destination"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("duration_days"),
                        rs.getDate("start_date").toLocalDate(),
                        rs.getInt("available_slots")
                );
                trips.add(trip);
            }
        } catch (SQLException e) {
            System.err.println("Ошибка при получении списка поездок: " + e.getMessage());
        }

        return trips;
    }

    public boolean addTrip(Trip trip) {
        String query = "INSERT INTO trips (destination, description, price, duration_days, start_date, available_slots) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, trip.getDestination());
            pstmt.setString(2, trip.getDescription());
            pstmt.setDouble(3, trip.getPrice());
            pstmt.setInt(4, trip.getDurationDays());
            pstmt.setDate(5, Date.valueOf(trip.getStartDate()));
            pstmt.setInt(6, trip.getAvailableSlots());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Ошибка при добавлении поездки: " + e.getMessage());
            return false;
        }
    }

    public Trip getTripById(int id) {
        String query = "SELECT * FROM trips WHERE id = ?";
        Trip trip = null;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                trip = new Trip(
                        rs.getInt("id"),
                        rs.getString("destination"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("duration_days"),
                        rs.getDate("start_date").toLocalDate(),
                        rs.getInt("available_slots")
                );
            }
        } catch (SQLException e) {
            System.err.println("Ошибка при получении поездки: " + e.getMessage());
        }

        return trip;
    }

    public boolean updateAvailableSlots(int tripId, int newAvailableSlots) {
        String query = "UPDATE trips SET available_slots = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, newAvailableSlots);
            pstmt.setInt(2, tripId);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Ошибка при обновлении количества мест: " + e.getMessage());
            return false;
        }
    }
}