module org.example.travel_agency {
    requires javafx.controls;
    requires javafx.fxml;

    requires java.sql;

    opens org.example.travel_agency to javafx.fxml;
    exports org.example.travel_agency;
}